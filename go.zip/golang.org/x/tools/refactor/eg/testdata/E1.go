// +build ignore

package E1

import "log"

func example() {
	log.Fatal("oops") // match
}
